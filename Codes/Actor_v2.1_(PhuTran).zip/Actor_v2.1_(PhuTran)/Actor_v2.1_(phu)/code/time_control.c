// FILE TIME_CONTROL DUNG DE SETUP CAC THONG SO CUA THOI GIAN
// DA BAO GOM KHAI BAO CAC THONG SO CAN THIET
// include cac ham can thiet vao thu vien
//#include "lcdfixed.c"      // khai bao ham cho lcd
//-------------------------------------------------------------
// khai bao cac nut bam
#define SET_BTN     PIND.2
#define UP_BTN      PIND.3
#define DOWN_BTN    PIND.4
#define MENU_BTN    PIND.5
//Nut an chon che do manual-auto
//auto :  tu dong dieu khien bom theo
//manual: do nguoi dung tu setup va dieu khien. 
#define  Speaker  PORTD.7             // 

#define  LED_LCD  PORTA.7             // 

//define cac van dien tu
//bien luu trang thai cac van
unsigned char van_status[6];
//bien luu gia tri thoi gian tam thoi
unsigned char   second,minute,hour,day=1,date,month,year;
unsigned char   temp_max, huff_max,;   
//bien luu xem dang chinh gio, phut, giay, ngay thang?
unsigned char state_settime=1,set_flag_mode2,set_flag_mode3,STT_time_on;
unsigned char maybom_on=0,count_in=0;
unsigned char mode_run=0,menu_system,mode_run_flag=1;
struct Time_on_off
{
   unsigned char hour_on;
   unsigned char minute_on;
   unsigned char time_on;
   unsigned char state_on;
};

struct Time_on_off DEV_INFO[5];
//time----------------------------------------------------------------------
//bien luu tiet hoc dung cho auto alarm
unsigned long sum_on_min,sum_on_max,sum_on; 

//-------------------------------------------------------------------------
void put_time(unsigned char time,int x, int y);
void put_date_info();
void put_time_info();
void lcd_blink_on();
//void lcd_blink_off();
void lcd_display_status_van();
// ham hien thi trang thai cac van len lcd
void lcd_display_status_van()
{   
   
   if(van_status[0]==0)
   {
       lcd_gotoxy(9,3);
       lcd_putchar('T');
   }
   else 
   {
       lcd_gotoxy(9,3);
       lcd_putchar('B');
   };
   if(van_status[1]==0)
   {
       lcd_gotoxy(11,3);
       lcd_putchar('T');
   }
   else 
   {
       lcd_gotoxy(11,3);
       lcd_putchar('B');
   };
   if(van_status[2]==0)
   {
       lcd_gotoxy(13,3);
       lcd_putchar('T');
   }
   else 
   {
       lcd_gotoxy(13,3);
       lcd_putchar('B');
   };
   if(van_status[3]==0)
   {
       lcd_gotoxy(15,3);
       lcd_putchar('T');
   }
   else 
   {
       lcd_gotoxy(15,3);
       lcd_putchar('B');
   };
   if(van_status[4]==0)
   {
       lcd_gotoxy(17,3);
       lcd_putchar('T');
   }
   else 
   {
       lcd_gotoxy(17,3);
       lcd_putchar('B');
   };
   if(van_status[5]==0)
   {
       lcd_gotoxy(19,3);
       lcd_putchar('T');          
   }
   else 
   {
       lcd_gotoxy(19,3);
       lcd_putchar('B');
   };               
   if(!van_status[0]||!van_status[1]||!van_status[2]||!van_status[3]||!van_status[4]||!van_status[5])
   {
       lcd_gotoxy(5,3);
       lcd_putsf("off");
   }   
   else if(van_status[0]&&van_status[1]&&van_status[2]&&van_status[3]&&van_status[4]&&van_status[5])
   {
      lcd_gotoxy(5,3);
      lcd_putsf("on ");
   }
   
}
// ham doc cac gia tri tu ds1307

void update_time()
{
    rtc_get_time(&hour,&minute,&second);
    rtc_get_date(&day,&date,&month,&year);    
}
//------------------------------------------------------------------------------------
//dung ham put_time de in ra second, minute, hour, date, month, year
// input : gia tri cua bien can in ra
//         vi tri cua bien can in ra tren LCD
// output : none
void put_time(unsigned char time,int x, int y) 
{
    unsigned char time_low,time_high;
    // tach bien time thanh 2 so hien thi tren lcd
    time_high = time/10 + 0x30;
    time_low  = time%10 + 0x30; 
    // di den vi tri x,y hien thi gia tri time
    lcd_gotoxy(x,y);
    lcd_putchar(time_high);
    lcd_putchar(time_low );
}

//-----------------------------------------------------------------------------------
//void put_data_info : hien thi thong tin thu ngay thang tren lcd
//input: none
//output: none
void put_date_info()
{   lcd_gotoxy(8,1);
    switch(day)
    { 
        // neu la chu nhat 
        case 1:
            lcd_putsf(" CN ");
         break;
        // neu la thu 2 
        case 2:
            lcd_putsf(" T2 ");
        break;
        //neu la thu 3
        case 3:
            lcd_putsf(" T3 ");
        break; 
        // neu la thu 4
        case 4:
            lcd_putsf(" T4 ");
        break; 
        // neu la thu 5
        case 5:
            lcd_putsf(" T5 ");
        break; 
        // neu la thu 6
        case 6:
            lcd_putsf(" T6");
        break; 
        // neu la thu 7
        case 7:
            lcd_putsf(" T7");
        break; 
        // neu khong co truong hop nao thi out
        default: 
        break;
    }   
    lcd_putchar('-');
    lcd_gotoxy(12,1); 
    put_time(date,12,1);
    lcd_putchar('/');
    put_time(month,15,1);
    lcd_putchar('/');
    //lcd_putsf("20");
    put_time(year,18,1);
 }
//-----------------------------------------------------------------------------------
//void put_data_info : hien thi thong tin gio phut giay len LCD
//input: gia tri gio phut giay
//output: none
void put_time_info()
{
    lcd_gotoxy(0,1);
    put_time(hour,0,1);
    lcd_putchar(':');
    put_time(minute,3,1);   
    lcd_putchar(':');      
    put_time(second,6,1);
}

//------------------------------------------------------------------------------------   
// hien thi trang thai nhap nhay tren lcd
void lcd_blink_on()
{
    lcd_putchar(' ');  //B0D 1101
    lcd_putchar(' ');  //B0D 1101
    delay_ms(100);
}

//----------------------------------------------------------------------------------
// hien thi trang thai nhap nhay(tat nhap nhay)
/*
void lcd_blink_off()
{
    lcd_putchar(0x0C);
    delay_us(1);
} */
// =================================================================================
// ham thuc hien chuong trinh chay cho mode 2 
// su dung timer de hien thi thoi gian led lcd
void set_time()
{
    // gia tri gio da duoc doc ra gio hien thi len lcd
   if(state_settime)// dung de hien thi 1 lan duy nhat
   {
        lcd_gotoxy(0,1);
        lcd_putsf("Setup time          ");
        lcd_gotoxy(0,2);
        lcd_putsf("                    ");  
        lcd_gotoxy(0,3);
        lcd_putsf("                    "); 
        // hien thi gia tri thoi gian ra lcd   
        put_time(hour,4,2);
        lcd_putchar(':');
        put_time(minute,7,2);
        lcd_putchar(':');
        put_time(second,10,2); 
        // duoc set lai bang 1 khi chuuyen che do setup
        state_settime=0;
        set_flag_mode2=0;
   }  
   
   // khi nut menu duoc bam chuyen cac che do hoat dong trong mode 2
   if(!SET_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      // cho den khi nut duoc nha ra
      while(!SET_BTN);
      //tang bien chuyen che do
      set_flag_mode2++;
      if(set_flag_mode2==5)        
      {
         set_flag_mode2=0;
         // xoa dong stored di
         lcd_gotoxy(0,3);
         lcd_putsf("                    ");      
      }
   } 
   // su ly cac trang thai co. setup thoi gian thuc  
   switch(set_flag_mode2)
   {
      // de do trang thai nhap nhay tai vi tri cua giay.
      // neu an nut tang giam thi se thay doi gia tri giay
      case 0:  
      {    
         lcd_gotoxy(10,2); 
         lcd_blink_on(); 
         //delay_ms(10);
         put_time(second,10,2);
         delay_ms(100);
         if(!UP_BTN)          //neu bam nut sub--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            second++;
            if(second==60)        second=0; 
            // hien thi len lcd   
            //put_time(second,11,3);
         } 
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            second--;
            if(second==255)        second=59; 
            // hien thi len lcd
            //put_time(second,11,3);
            
         } 
      } 
      break;
      // neu an nut tang giam thi se thay doi gia tri phut
      case 1:             
      {
         lcd_gotoxy(7,2); 
         lcd_blink_on(); 
         put_time(minute,7,2);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            minute++;
            if(minute==60)    minute=0; 
           // put_time(minute,8,3); 
          }
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
                    //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            minute--;
            if(minute==255)   minute=59;
           // put_time(minute,8,3);
         }
     }
      break;
      // neu an nut tang giam thi se thay doi gia tri gio
      case 2:             //set minute
      {    
         lcd_gotoxy(4,2); 
         lcd_blink_on(); 
         put_time(hour,4,2);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            hour++;
            if(hour==24)   hour=0;   
            //put_time(hour,5,3); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            hour--;
            if(hour==255)   hour=23;   
            //put_time(hour,5,3); 
         }
       }
      break;
      // luu gia tri setup vao ds1307
      case 3:            
      {
         //lcd_blink_off(); 
         lcd_gotoxy(0,3);
         lcd_putsf(">Stored       ");
         set_flag_mode2=4;           
         rtc_set_time(hour,minute,second) ;
//         rtc_write(0x00,second);
//         rtc_write(0x01,minute);
//         rtc_write(0x02,hour);
         // luu gia tri vao ds 1307
      }
      break;
      // 
      default:
      break;
   }
}
// ham dung set date
void set_date()
{
    // gia tri gio da duoc doc ra gio hien thi len lcd
   if(state_settime)// dung de hien thi 1 lan duy nhat
   {
        lcd_gotoxy(0,1);
        lcd_putsf("Setup date          ");
        lcd_gotoxy(0,2);
        lcd_putsf("                    ");  
        lcd_gotoxy(0,3);
        lcd_putsf("                    "); 
        //put_date_info();
        put_time(date,6,2);
        lcd_putchar('/');
        put_time(month,9,2);
        lcd_putchar('/');
        lcd_putsf("20");
        put_time(year,14,2);   
        lcd_gotoxy(17,2); 
        switch(day)
    { 
        // neu la chu nhat 
        case 1:
            lcd_putsf(" CN ");
         break;
        // neu la thu 2 
        case 2:
            lcd_putsf(" T2 ");
        break;
        //neu la thu 3
        case 3:
            lcd_putsf(" T3 ");
        break; 
        // neu la thu 4
        case 4:
            lcd_putsf(" T4 ");
        break; 
        // neu la thu 5
        case 5:
            lcd_putsf(" T5 ");
        break; 
        // neu la thu 6
        case 6:
            lcd_putsf(" T6");
        break; 
        // neu la thu 7
        case 7:
            lcd_putsf(" T7");
        break; 
        // neu khong co truong hop nao thi out
        default: 
        break;
    }
        // duoc set lai bang 1 khi chuuyen che do setup
        state_settime=0;
        set_flag_mode2=0;
   }  
   
   // khi nut menu duoc bam chuyen cac che do hoat dong trong mode 2
   if(!SET_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      // cho den khi nut duoc nha ra
      while(!SET_BTN);
      //tang bien chuyen che do
      set_flag_mode2++;
      if(set_flag_mode2==6
      )        
         {
            set_flag_mode2=0;
            // xoa dong stored di
            lcd_gotoxy(0,3);
            lcd_putsf("                  ");
            
         }
   } 
   // su ly cac trang thai co. setup thoi gian thuc  
   switch(set_flag_mode2)
   {
      // de do trang thai nhap nhay tai vi tri cua giay.
      // neu an nut tang giam thi se thay doi gia tri giay
      case 0:  
      {    
         lcd_gotoxy(9,2); 
         lcd_blink_on(); 
         put_time(month,9,2);
         delay_ms(100);
         
         if(!UP_BTN)          //neu bam nut sub--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            month++;
            if(month==13)        month=1; 
            // hien thi len lcd
            //put_time(month,10,3);
            
         } 
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            month--;
            if(month==0)        month=12; 
            // hien thi len lcd
            //put_time(month,10,3);
            
         } 
      } 
      break;
      // neu an nut tang giam thi se thay doi gia tri phut
      case 1:             
      {
         lcd_gotoxy(6,2); 
         lcd_blink_on(); 
         put_time(date,6,2); 
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            date++;
            if(date==32)    date=1; 
            //put_time(date,7,3); 
          }
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
                    //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            date--;
            if(date==0)   date=31;
            //put_time(date,7,3);
         }
     }
      break;
      // neu an nut tang giam thi se thay doi gia tri gio
      case 2:             //set minute
      {    
         lcd_gotoxy(14,2); 
         lcd_blink_on(); 
         put_time(year,14,2);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            year++;
            if(year==100)   year=0;
           // put_time(year,15,3); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            year--;
            if(year==255)   year=99;   
           // put_time(hour,15,3); 
         }
       }
      break;  
      case 3:
      {
         lcd_gotoxy(18,2); 
         //lcd_blink_on(); 
         lcd_putsf("   ");
         lcd_gotoxy(18,2);
         switch(day)
    { 
        // neu la chu nhat 
        case 1:
            lcd_putsf("CN ");
         break;
        // neu la thu 2 
        case 2:
            lcd_putsf("T2 ");
        break;
        //neu la thu 3
        case 3:
            lcd_putsf("T3 ");
        break; 
        // neu la thu 4
        case 4:
            lcd_putsf("T4 ");
        break; 
        // neu la thu 5
        case 5:
            lcd_putsf("T5 ");
        break; 
        // neu la thu 6
        case 6:
            lcd_putsf("T6 ");
        break; 
        // neu la thu 7
        case 7:
            lcd_putsf("T7 ");
        break; 
        // neu khong co truong hop nao thi out
        default: 
        break;
    }
     
       if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            day++;
            if(day==8) 
              day=1;
           // put_time(year,15,3); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            day--;
            if(day==0)   day=7;   
           // put_time(hour,15,3); 
         }
      }
      break;
      case 4:            
      {
         //lcd_blink_off(); 
         lcd_gotoxy(0,3);
         lcd_putsf(">Stored OK     ");
         rtc_set_date(day,date,month,year);
         set_flag_mode2=5;
      }
      break;
      // 
      default:
      break;
   }
}
/////////////////////////////////////
// ham phuc vu dieu khien bang tay tu phim bam
/////////////////////////////////////
void dk_bang_tay()
{
   if(state_settime)// dung de hien thi 1 lan duy nhat
   {
        lcd_gotoxy(0,0);
        lcd_putsf("MODE3: DK BANG TAY");
        lcd_gotoxy(0,1);
        lcd_putsf("Bam SET De Chon Van");    
        lcd_gotoxy(0,2);
        lcd_putsf("Van: all 1 2 3 4 5 6");
        lcd_gotoxy(0,3);
        lcd_putsf("T/T:");
        lcd_display_status_van();
        state_settime=0;
        set_flag_mode3=0;
   }   
   if(!SET_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      // cho den khi nut duoc nha ra
      while(!SET_BTN);
      //tang bien chuyen che do
      set_flag_mode3++;
      if(set_flag_mode3==8)        
         {
            set_flag_mode3=0;
            // xoa dong stored di
            lcd_gotoxy(0,3);
            lcd_putsf("       ");
            
         }
   }      
         lcd_gotoxy(0,1);
         lcd_putsf("Bam SET De Chon Van");
         lcd_gotoxy(0,2);
         lcd_putsf("Van: all 1 2 3 4 5 6");
         lcd_gotoxy(0,3);
         lcd_putsf("T/T:");  
         delay_ms(250);
         lcd_display_status_van(); 
         if(Van1||Van2||Van3||Van4||Van5||Van6)
            MAYBOM=1;
         else
            MAYBOM=0;   
   switch(set_flag_mode3)   
   {
   case 0:
      {
         lcd_gotoxy(0,1);
         lcd_putsf("                    ");
         delay_ms(250);    
      }
      break;
   case 1:
      {
         lcd_gotoxy(5,2);
         lcd_putsf("   ");  
         delay_ms(250);
         if(!UP_BTN)
           {
              on_all_van();   
           }
         else if(!DOWN_BTN)
          {
             off_all_van(); 
          }   
      }  
      break;
   case 2:
      {
         lcd_gotoxy(9,2);
         lcd_putsf(" ");    
         delay_ms(250);
         if(!UP_BTN)
           {
              Van1=1;
              van_status[0]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van1=0; 
             van_status[0]=0;
          } 
      }   
      break;
      case 3:
      {
         lcd_gotoxy(11,2);
         lcd_putsf(" "); 
         delay_ms(250);
         if(!UP_BTN)
           {
              Van2=1;
              van_status[1]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van2=0; 
             van_status[1]=0;
          } 
      }   
      break;
      case 4:
      {
         lcd_gotoxy(13,2);
         lcd_putsf(" ");
         delay_ms(250); 
         if(!UP_BTN)
           {
              Van3=1;
              van_status[2]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van3=0; 
             van_status[2]=0;
          } 
      }   
      break;
      case 5:
      {
         lcd_gotoxy(15,2);
         lcd_putsf(" ");
         delay_ms(250); 
         if(!UP_BTN)
           {
              Van4=1;
              van_status[3]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van4=0; 
             van_status[3]=0;
          } 
      }   
      break;
      case 6:
      {
         lcd_gotoxy(17,2);
         lcd_putsf(" ");
         delay_ms(250); 
         if(!UP_BTN)
           {
              Van5=1;
              van_status[4]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van5=0; 
             van_status[4]=0;
          } 
      }   
      break;
      case 7:
      {
         lcd_gotoxy(19,2);
         lcd_putsf(" ");
         delay_ms(250); 
         if(!UP_BTN)
           {
              Van6=1;
              van_status[5]=1; 
           }
         else if(!DOWN_BTN)
          {
             Van6=0; 
             van_status[5]=0;
          } 
      }   
      break;

      default:
      break; 
   }
}

// ham set thoi gian on off cho may bom-> che do 2 (dieu khien bom)
// ham nay duoc goi khi dang o che do 2 con o cac che do khac
// ham nay khong duoc goi den
void set_time_on_off()
{
    // gia tri gio da duoc doc ra gio hien thi len lcd
   if(state_settime)// dung de hien thi 1 lan duy nhat
   {
        lcd_gotoxy(0,0);
        lcd_putsf("MODE2:");
        lcd_putsf("Thoi gian bom");  
        lcd_gotoxy(0,2);
        lcd_putsf("           ON:  :");  
        lcd_gotoxy(0,3);
        lcd_putsf("           IN:    p"); 
        STT_time_on=1;
        //lcd_gotoxy(15,2);
      //  lcd_putchar(STT_time_on);
       put_time(DEV_INFO[STT_time_on].hour_on,14,2);
        put_time(DEV_INFO[STT_time_on].minute_on,17,2);
        put_time(DEV_INFO[STT_time_on].time_on,15,3);
        lcd_gotoxy(0,2);
        if(DEV_INFO[STT_time_on].state_on==1)
           lcd_putsf("Enable ");
        else
           lcd_putsf("Disable");
        // duoc set lai bang 1 khi chuuyen che do setup
        state_settime=0;
        set_flag_mode2=0;
   }  
   
   // khi nut menu duoc bam chuyen cac che do hoat dong trong mode 2
   if(!SET_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      // cho den khi nut duoc nha ra
      while(!SET_BTN);
      //tang bien chuyen che do
      set_flag_mode2++;
      if(set_flag_mode2==7)        
         {
            set_flag_mode2=0;
            // xoa dong stored di
            lcd_gotoxy(0,3);
            lcd_putsf("       ");
            
         }
   } 
   // su ly cac trang thai co. setup thoi gian thuc  
   switch(set_flag_mode2)
   {
      // de do trang thai nhap nhay tai vi tri cua .
      // neu an nut tang giam thi se thay doi gia tri giay
      case 0:  
      {
         lcd_gotoxy(0,1);
         lcd_putsf("                    ");
         delay_ms(250);
         lcd_gotoxy(0,1);
         //lcd_putchar(STT_time_on);
         lcd_putsf("Bam set de bat dau");
         delay_ms(250);
      } 
      break;
      // chon che do la disable hay enable gio bat tat may bom
      case 1:             
      {
         lcd_gotoxy(0,2); 
         lcd_blink_on();
         lcd_gotoxy(0,2); 
         if(DEV_INFO[STT_time_on].state_on==1)               
               lcd_putsf("Enable");
         else
               lcd_putsf("Disable ");
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            lcd_gotoxy(0,2); 
            if(DEV_INFO[STT_time_on].state_on==1)               
            {
               lcd_putsf("Disable");
               DEV_INFO[STT_time_on].state_on=0;
            }
            else
            {
               lcd_putsf("Enable ");
               DEV_INFO[STT_time_on].state_on=1;
            }
          }
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
                    //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            lcd_gotoxy(0,2); 
            if(DEV_INFO[STT_time_on].state_on==1)               
            {
               lcd_putsf("Disable");
               DEV_INFO[STT_time_on].state_on=0;
            }
            else
            {
               lcd_putsf("Enable ");
               DEV_INFO[STT_time_on].state_on=1;
            }
         }
     }
      break;
      // neu an nut tang giam thi se thay doi gia tri gio bat bom
      case 2:             //set hour
      {    
         lcd_gotoxy(14,2); 
         lcd_blink_on(); 
         put_time(DEV_INFO[STT_time_on].hour_on,14,2);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            DEV_INFO[STT_time_on].hour_on++;
            if(DEV_INFO[STT_time_on].hour_on==24)   DEV_INFO[STT_time_on].hour_on=0;   
            //put_time(DEV_INFO[STT_time_on].hour_on,16,3); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            DEV_INFO[STT_time_on].hour_on--;
            if(DEV_INFO[STT_time_on].hour_on==254||DEV_INFO[STT_time_on].hour_on==255) DEV_INFO[STT_time_on].hour_on=23; 
            //put_time(DEV_INFO[STT_time_on].hour_on,16,3); 
         }
       }
      break;
      // neu an nut tang giam thi se thay doi gia tri phut bat
      case 3:             //set minute
      {    
         lcd_gotoxy(18,2); 
         lcd_blink_on(); 
         put_time(DEV_INFO[STT_time_on].minute_on,17,2);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            if(DEV_INFO[STT_time_on].minute_on==255)
               DEV_INFO[STT_time_on].minute_on=0;
            DEV_INFO[STT_time_on].minute_on+=5;
            if(DEV_INFO[STT_time_on].minute_on==60||DEV_INFO[STT_time_on].minute_on==255) 
              DEV_INFO[STT_time_on].minute_on=0;   
            
            //put_time(DEV_INFO[STT_time_on].minute_on,19,3); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            DEV_INFO[STT_time_on].minute_on-=5;
            if(DEV_INFO[STT_time_on].minute_on>=250)   DEV_INFO[STT_time_on].minute_on=55;   
            //put_time(DEV_INFO[STT_time_on].minute_on,19,3); 
         }
       }
      break;
      // luu gia tri setup vao ds1307
      case 4:            
      {
         lcd_gotoxy(16,3); 
         lcd_blink_on(); 
         put_time(DEV_INFO[STT_time_on].time_on,15,3);
         delay_ms(100);
         if(!UP_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            if(DEV_INFO[STT_time_on].time_on==255) DEV_INFO[STT_time_on].time_on=0;
            DEV_INFO[STT_time_on].time_on+=5;
            if(DEV_INFO[STT_time_on].time_on==65)   DEV_INFO[STT_time_on].time_on=0;   
            //put_time(DEV_INFO[STT_time_on].time_on,17,4); 
         }
         if(!DOWN_BTN)            //neu bam button add------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150);
            DEV_INFO[STT_time_on].time_on-=5;
            if(DEV_INFO[STT_time_on].time_on>=250)   DEV_INFO[STT_time_on].time_on=60;   
            //put_time(DEV_INFO[STT_time_on].time_on,17,4); 
         }
      }
      break;
      // luu cac gia tri da set vao eeprom tren 24LC01
      case 5:
      {
         write_ext_eeprom(0x0A+4*STT_time_on+0,DEV_INFO[STT_time_on].hour_on);
         write_ext_eeprom(0x0A+4*STT_time_on+1,DEV_INFO[STT_time_on].minute_on);
         write_ext_eeprom(0x0A+4*STT_time_on+2,DEV_INFO[STT_time_on].time_on);
         write_ext_eeprom(0x0A+4*STT_time_on+3,DEV_INFO[STT_time_on].state_on);
         // hien thi len lcd trang thai da luu du lieu vao eeprom
         lcd_gotoxy(0,3);
         lcd_putsf(">Stored Ok!");
         set_flag_mode2=6;
         
      }
      break;
      default:
      break;
   }
}

// ham loa du lieu tu eeprom
void load_eeprom()
{
   unsigned char i;
   for(i=1;i<5;i++)
   {
      DEV_INFO[i].hour_on   = read_ext_eeprom(0x0A+4*i+0);
      DEV_INFO[i].minute_on = read_ext_eeprom(0x0A+4*i+1);
      DEV_INFO[i].time_on   = read_ext_eeprom(0x0A+4*i+2);
      DEV_INFO[i].state_on  = read_ext_eeprom(0x0A+4*i+3);
   }
   // load du lieu temp_max
   temp_max = read_ext_eeprom(0x07);
   huff_max = read_ext_eeprom(0x08);
   mode_run = read_ext_eeprom(0x09);
   if(mode_run<1 || mode_run>3)
      mode_run=1;
}
// ham chay khi dang o mode 2
void run_mode2()
{
   unsigned char count;
   for(count=1;count<4;count++)
   {
      if(maybom_on==0)
      {
         sum_on_max=DEV_INFO[count].hour_on*60+DEV_INFO[count].minute_on+DEV_INFO[count].time_on;
         sum_on_min=DEV_INFO[count].hour_on*60+DEV_INFO[count].minute_on-1;
         count_in=count;
      }
      sum_on=  hour*60+minute;
      if(sum_on<sum_on_max&&sum_on>sum_on_min&&DEV_INFO[count_in].state_on==1)
      {         
         on_all_van();
         //lcd_gotoxy(0,2);
         //lcd_putsf("Bom ON");
         delay_ms(50);
//         if(maybom_on==0)
//            lcd_init(20);
         maybom_on=1;
      }
      else
      {

         off_all_van();
         delay_ms(50);
         //lcd_gotoxy(0,2);
         //lcd_putsf("Bom OFF ");
         maybom_on=0;
      }
   }
}

// ham setup cac mode hoat dong cho mach
void set_mode()
{
    // gia tri gio da duoc doc ra gio hien thi len lcd
   if(state_settime)// dung de hien thi 1 lan duy nhat
   {
        lcd_gotoxy(0,1);
        lcd_putsf("SETUP MODE :        ");
        lcd_gotoxy(0,2);
        lcd_putsf("                    ");  
        lcd_gotoxy(0,3);
        lcd_putsf("                    "); 
        mode_run_flag=mode_run;
        lcd_gotoxy(11,1);
        lcd_putchar(mode_run_flag+0x30);
        // duoc set lai bang 1 khi chuuyen che do setup
        state_settime=0;
        set_flag_mode2=0;
   }  
   
   // khi nut menu duoc bam chuyen cac che do hoat dong trong mode 2
   if(!SET_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      // cho den khi nut duoc nha ra
      while(!SET_BTN);
      //tang bien chuyen che do
      set_flag_mode2++;
      if(set_flag_mode2==3)        
         {
            set_flag_mode2=0;
            // xoa dong stored di
            lcd_gotoxy(0,2);
            lcd_putsf("       ");
            
         }
   } 
   // su ly cac trang thai co. setup thoi gian thuc  
   switch(set_flag_mode2)
   {
      // de do trang thai nhap nhay tai vi tri cua .
      // neu an nut tang giam thi se thay doi gia tri giay
      case 0:  
      {
         lcd_gotoxy(11,1);
         lcd_putchar(' ');
         delay_ms(100);
         lcd_gotoxy(11,1);
         lcd_putchar(mode_run_flag+0x30);
         delay_ms(100);
         if(!UP_BTN)          //neu bam nut add--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            mode_run_flag++;
            if(mode_run_flag==4)        mode_run_flag=1;         
         } 
         if(!DOWN_BTN)          //neu bam nut sub--------
         {
            //cho toi khi tha nut bam
            Speaker = 1;
            delay_ms(150);
            Speaker = 0;
            delay_ms(150); 
            mode_run_flag--;
            if(mode_run_flag==0)        mode_run_flag=3;             
         } 
      } 
      break;
      // chon che do la disable hay enable gio bat tat may bom
      case 1:             
      {
         lcd_gotoxy(0,2); 
         lcd_putsf(">Stored");
         mode_run=mode_run_flag;
         lcd_gotoxy(0,0);
         lcd_putsf("  CHE DO : MODE    ");
         lcd_gotoxy(15,0);
         lcd_putchar(mode_run+0x30); 
         //thuc hien qua trinh ngat uart khi chuyen mode khong con o mode 2
         if(mode_run==2) {
            UCSRB=0x98;
            UCSRC=0x86;   }
         if(mode_run!=2)   {
            UCSRB=0x98;
            UCSRC=0x86;   }
         //neu nhu chuyen mode khi mode 2 dang hoat dong
         // mode 2 dang trong thoi gian bat bom-> tat bom
         if(maybom_on==1)
            maybom_on=0;
         //luu vao eeprom
         write_ext_eeprom(0x09,mode_run);
         off_all_van();
         set_flag_mode2=2;
      }
      break; 
      default:
      break;
   }
}

