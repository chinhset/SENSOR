#define Van1        PORTD.6
#define Van2        PORTC.7
#define Van3        PORTC.6
#define Van4        PORTC.5
#define Van5        PORTC.4
#define Van6        PORTC.3
#define MAYBOM      PORTC.2

#define Van1_IO        DDRD.6
#define Van2_IO        DDRC.7
#define Van3_IO        DDRC.6
#define Van4_IO        DDRC.5
#define Van5_IO        DDRC.4
#define Van6_IO        DDRC.3
#define MAYBOM_IO      DDRC.2
// khai bao cac chan dieu khien 74HC595
#define LAT1_595        PORTB.5
#define SCK1_595        PORTB.6
#define DATA1_595       PORTB.4
#define LAT1_595_IO      DDRB.4
#define SCK1_595_IO      DDRB.5
#define DATA1_595_IO     DDRB.6

//
#define sht_van1        1
#define sht_van2        2
#define sht_van3        3
#define sht_van4        4
#define sht_van5        5
#define sht_van6        6
#define sht_maybom      7
//bien luu tt cac van
extern unsigned char van_status[6];


// ham dua du lieu 1 byte ra tung bit tren 1 pin vi dieu khien
void led_control(unsigned char data)
{
    unsigned char i,temp;
    for(i=0;i<8;i++)
    {
        temp=data;             //gan bien
        temp=temp&0x80;     //lay ra bit dau tien (bit 7)
        if(temp==0x80)      //so sanh bit
            DATA1_595=1;         //bang 1 thi xuat vao chip =1
        else
            DATA1_595=0;         //nguoc lai bang 0
        data*=2;               //dich bit lay bit trong so thap
        SCK1_595=0;          //tao xung tren chan 11
        SCK1_595=1;          //1 xung dua v�o 1 b�t
    }
    LAT1_595=1;              // tao 1 xung tai pin lat cua 74hc595
    LAT1_595=0;              // day du lieu tai tat ca cac pin ra
}

void setup_io_dieukhien()
{
   Van1_IO=0;
   Van2_IO=0;
   Van3_IO=0;
   Van4_IO=0;
   Van5_IO=0;
   Van6_IO=0;
   MAYBOM_IO=0;
   led_control(0xff);
}
// ham bat tat ca cac van dieu tu len
void on_all_van()
{
   Van1=1;
   Van2=1;
   Van3=1;
   Van4=1;
   Van5=1;
   Van6=1;
   MAYBOM=1;
   van_status[0]=van_status[1]=van_status[2]=van_status[3]=van_status[4]=van_status[5]=1;
   led_control(0x00); 
}
// ham tat het cac van dien tu
void off_all_van()
{
   MAYBOM=0;
   Van1=0;
   Van2=0;
   Van3=0;
   Van4=0;
   Van5=0;
   Van6=0;
   van_status[0]=van_status[1]=van_status[2]=van_status[3]=van_status[4]=van_status[5]=0;
   led_control(0xff);
}
// ham nay duoc su dung trong ngat uart khi nhan ban tin dieu khien
// tu gateway
// bien rx_data la bien luu gia tri data nhan tu uart
void dieukhien_van(char data)
{
   
   unsigned long i;
   //nhan du lieu va dua vao du lieu nhan dc vao bien data
   // check xem ban tin du lieu la gi
   switch(data)
   {
      // nhan duoc ban tin bat van 1
      case 0x81:
      {
         Van1=1;
         van_status[0]=1;                 // bat van 1
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x81);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1;  
         dislay_led_van&=~(Van1<<sht_van1);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ; 
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien van 2
      case 0x82:
      {
         Van2=1;
         van_status[1]=1;                 // bat van 2
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x82);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1  ; 
         dislay_led_van &=~(Van2<<sht_van2);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ;
         led_control(dislay_led_van);      
      }
      break;
      // nhan duoc ban tin dieu khien van 3
      case 0x83:
      {
         Van3=1;
         van_status[2]=1;                 // bat van 3
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x83);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1   ;   
         dislay_led_van &=~(Van3<<sht_van3);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ;
         led_control(dislay_led_van);   
      }
      break;
      // nhan duoc ban tin dieu khien van 4
      case 0x84:
      {
         Van4=1; 
         van_status[3]=1;                // bat van 4
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x84);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1  ;
         dislay_led_van &=~(Van4<<sht_van4);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ;
         led_control(dislay_led_van);     
      }
      break;
      // nhan duoc ban tin dieu khien van 5
      case 0x85:
      {
         Van5=1;    
         van_status[4]=1;             // bat van 5
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x85);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1   ;   
         dislay_led_van &=~(Van5<<sht_van5);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ;
         led_control(dislay_led_van);    
      }
      break;
      // nhan duoc ban tin dieu khien van 6
      // van 6 dung cho vuon tue
      case 0x86:
      {
         Van6=1;     
         van_status[5]=1;            // bat van 6
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x86);
         // check xem may bom co duoc bat khong?
         // neu may bom dang tat thi bat may bom len 
         if(MAYBOM!=1) MAYBOM=1   ; 
         dislay_led_van &=~(Van6<<sht_van6);
         dislay_led_van &= ~(MAYBOM<<sht_maybom) ;
         led_control(dislay_led_van);    
      }
      break;
      // nhan duoc ban tin bat tat ca cac van 
      case 0x8F:
      {               
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x8F);
         on_all_van();   
      }
      break;
      // nhan duoc ban tin dieu khien tat van 1
      case 0x01:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x01);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van2==0&&Van3==0&&Van4==0&&Van5==0&&Van6==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);
         }
         Van1=0;
         van_status[0]=0;                 // tat van 1  
         dislay_led_van |=(0x01<<sht_van1);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ; 
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat van 2
      case 0x02:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x02);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van1==0&&Van3==0&&Van4==0&&Van5==0&&Van6==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);
         }
         Van2=0;
         van_status[1]=0;                 // tat van 2 
         dislay_led_van |=(0x01<<sht_van2);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ;   
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat van 3
      case 0x03:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x03);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van1==0&&Van2==0&&Van4==0&&Van5==0&&Van6==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);
         }
         Van3=0;     
         van_status[2]=0;            // tat van 3  
         dislay_led_van |=(0x01<<sht_van3);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ;    
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat van 4
      case 0x04:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x04);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van1==0&&Van2==0&&Van3==0&&Van5==0&&Van6==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);
         }
         Van4=0;     
         van_status[3]=0;            // tat van 4  
         dislay_led_van |=(0x01<<sht_van4);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ;  
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat van 5
      case 0x05:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x05);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van1==0&&Van2==0&&Van3==0&&Van4==0&&Van6==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);
         }
         Van5=0;     
         van_status[4]=0;            // tat van 5
         dislay_led_van |=(0x01<<sht_van5);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ;     
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat van 6
      case 0x06:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x06);
         // check xem co con van nao duoc bat khong?
         // neu nhu cac van tat het thi tat may bom
         // sau do moi tat van duoc dieu khien
         if(Van1==0&&Van2==0&&Van3==0&&Van4==0&&Van5==0) 
         {
            MAYBOM=0;
            // tre 1 khoang thoi gian roi moi tat van dieu khien
            for(i=0;i<1000;i++);   
         }  
         Van6=0;        
         van_status[5]=0;         // tat van 1
         dislay_led_van |=(0x01<<sht_van6);
         dislay_led_van |= ((~MAYBOM)<<sht_maybom) ;                                             
         led_control(dislay_led_van);
      }
      break;
      // nhan duoc ban tin dieu khien tat het cac van
      case 0x0F:
      {
         //gui lai ban tin phan hoi cho gateway thong qua uart
         USART_Transmit(0x0F);
         off_all_van();
         
      }
      default:
      break;
   }
   data=0;
}
