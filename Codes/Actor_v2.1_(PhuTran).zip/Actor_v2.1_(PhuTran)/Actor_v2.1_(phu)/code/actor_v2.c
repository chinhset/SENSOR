/*****************************************************
This program was produced by the
CodeWizardAVR V2.05.3 Standard
Automatic Program Generator
� Copyright 1998-2011 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 
Version :  2.1.0
Date    : 7/9/2013
Author  : TranVanPhu - K55
Company : If You Like This Software,Buy It
Comments: 


Chip type               : ATmega32L
Program type            : Application
AVR Core Clock frequency: 8.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*****************************************************/

#include <mega32.h>
#include <alcd.h>
// I2C Bus functions
#include <i2c.h>
unsigned char dislay_led_van=0xFF;

// DS1307 Real Time Clock functions
#include <ds1307.h>  
#include <delay.h>   
void USART_Transmit( unsigned char data )
{
    while ( !( UCSRA & (1<<UDRE)) );
    UDR = data;
} 
#include "dislay_seg.c"
#include "eeprom.c"
#include "mode1_run.c"
#include "time_control.c"

#ifndef RXB8
#define RXB8 1
#endif

#ifndef TXB8
#define TXB8 0
#endif

#ifndef UPE
#define UPE 2
#endif

#ifndef DOR
#define DOR 3
#endif

#ifndef FE
#define FE 4
#endif

#ifndef UDRE
#define UDRE 5
#endif

#ifndef RXC
#define RXC 7
#endif

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<DOR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)
#define set   1
#define clear 0

int count;   // bien dem timer de tat du phong khi mat ket noi voi may tinh nhung
int data_1, data_2, data_3, data_4, data_5, data_6;      // luu du lieu dieu khien tu USART
int van_1, van_2, van_3, van_4, van_5, van_6;           // luu trang thai cac van
extern unsigned char van_status[6];
//han bam phim
void switch_menu();
unsigned char times;
interrupt [TIM0_OVF] void timer0_ovf_isr(void)//interrupt of timer 0
{
//  sau 1 khoang thoi gian dinh san thi he thong cap nhat time len LCD va led 7 doan
   times++;//increase  variable until times=250; equal delay 250....    
   count++;  
    if(times==20){  
       if(menu_system==0 || menu_system==3)
        update_time();
        // hien thi led led 7 thanh
        dislay_seg(hour,minute);
        if(!led) led=1;
        else     led=0;  
        times=0;     
    }        
    if(count==200)  
    {
      van_1++; 
      van_2++;
      van_3++;
      van_4++;
      van_5++;
      van_6++;
      count=0;
    }
}
// ham nhan lenh qua USART
interrupt [USART_RXC] void usart_rx_isr(void)
{
// khai bao bien cuc bo
   char status,data;
   status=UCSRA;      //thanh ghi trang thai du lieu
   data=UDR;          // thanh ghi du lieu(data)
       /*test tren proteus - creat by tran-phu k55
        if(data==0x31)
        data=0x81;
        else if(data==0x32)
        data=0x82;
        else if(data==0x33)
        data=0x83;
        else if(data==0x34)
        data=0x84;
        else if(data==0x35)
        data=0x85;
        else if(data==0x36)
        data=0x86; 
        else if(data==0x37)
        data=0x01; 
        else if(data==0x38)
        data=0x0f;      
        ________________*/ 
if ((status & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
   {
   if(mode_run==1)         
   {  
      dieukhien_van(data);    
      switch(data)
       {  
         // neu van1 duoc set
          case 0x81:
           {
            van_1=clear; 
            data_1=0x81;
           }
          break;  
          case 0x01:
           {
            data_1=0x00;
           }  
          break;  
          // neu van2 duoc set
          case 0x82:
           {
            van_2=clear; 
            data_2=0x82;
           }
          break;  
          case 0x02:
           {
            data_2=0x00;
           }  
          break; 
          // neu van3 duoc set
          case 0x83:
           {
            van_3=clear; 
            data_3=0x83;
           }
          break;  
          case 0x03:
           {
            data_3=0x00;
           }  
          break;   
          // neu van4 duoc set
          case 0x84:
           {
            van_4=clear; 
            data_4=0x84;
           }
          break;  
          case 0x04:
           {
            data_4=0x00;
           }  
          break; 
          case 0x85:
           {
            van_5=clear; 
            data_5=0x85;
           }
          break;  
          case 0x05:
           {
            data_5=0x00;
           }  
          break;
          case 0x86:
           {
            van_6=clear; 
            data_6=0x86;
           }
          break;  
          case 0x06:
           {
            data_6=0x00;
           }  
          break;
       }
   }  /*
   if(mode_run==3)
   {
      unsigned char rx_buff[3],rx_count;
      rx_buff[rx_count++] = data;
      if(rx_count>1)
      {
         temp=rx_buff[0];
         huff=rx_buff[1];
         rx_count=0;
      }
   }    */
   }
}
#include <stdio.h>

void main(void)
{
PORTA=0x00;
DDRA=0xFF;
PORTB=0x00;
DDRB=0xFF;


PORTC=0x00;
DDRC=0xFC;

PORTD=0x3C;
DDRD=0xC0;

TCCR0=0x05;
TCNT0=0x00;
OCR0=0x00;

ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;


MCUCR=0x00;
MCUCSR=0x00;

TIMSK=0x01;

UCSRA=0x00;
UCSRB=0x98;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x19;

ACSR=0x80;
SFIOR=0x00;

ADCSRA=0x00;

SPCR=0x00;

TWCR=0x00;

i2c_init();
lcd_init(20);
rtc_init(0,1,0);
Init_595();
setup_io_dieukhien();
#asm("sei")
led_control(0xFF);
delay_ms(100);

   PORTA.7=1;
   menu_system=0;
   load_eeprom();
   off_all_van();
   delay_ms(100);
   Speaker=0;
    
while (1)
      {  
       //  dieukhien_van(0x01); 
      // Place your code here
        switch_menu();     
        if(data_1 == 0x81)
         {
          if(van_1 == 200)
           {
            dieukhien_van(0x01); 
            data_1=0x00;
           }
         }  
         if(data_2 == 0x82)
         {
          if(van_2 == 200)
           {
            dieukhien_van(0x02); 
            data_2=0x00;
           }
         }
         if(data_3 == 0x83)
         {
          if(van_3 == 200)
           {
            dieukhien_van(0x03); 
            data_3=0x00;
           }
         }
         if(data_4 == 0x84)
         {
          if(van_4 == 200)
           {
            dieukhien_van(0x04); 
            data_4=0x00;
           }
         }
         if(data_5 == 0x85)
         {
          if(van_5 == 200)
           {
            dieukhien_van(0x05); 
            data_5=0x00;
           }
         }
         if(data_6 == 0x86)
         {
          if(van_6 == 200)
           {
            dieukhien_van(0x06); 
            data_6=0x00;
           }
         }

      }
}
void switch_menu()
{
   if(!MENU_BTN)
   {
      // bat loa len tao xung o chan loa
      Speaker = 1;
      delay_ms(150);
      Speaker = 0;
      delay_ms(150); 
      state_settime=1;
      lcd_gotoxy(0,3);
      lcd_putsf("                    ");
      menu_system++;
      if(menu_system==5)   menu_system=0;
   }
   switch(menu_system)
   {
      // chay chuong trinh chinh
      case 0:
      {
         // chay chuong trinh chinh
         if(mode_run ==1)
         {
            // hien thi cac gia tri len lcd
            // hien thi che do mode len dong 1
            lcd_gotoxy(0,0);
           // update_time();
            // hien thi led led 7 thanh  
            lcd_putsf("  CHE DO : MODE 1   ");
            // hien thi thoi gian + date
            put_time_info();
            put_date_info();
            lcd_gotoxy(0,2);
            lcd_putsf("Van: all 1 2 3 4 5 6");
            lcd_gotoxy(0,3);
            lcd_putsf("T/T:");
            lcd_display_status_van();
            delay_ms(100);
            // chay chuong trinh tu uart dieu khien may bom
            
         }
         if(mode_run==2)
         {
            update_time();
            lcd_gotoxy(0,0);
            lcd_putsf("  CHE DO : MODE 2   ");
            // hien thi thoi gian + date
            put_time_info();
            lcd_putchar(' ');
            put_date_info();
            lcd_gotoxy(0,2);
            lcd_putsf("                    ");
            lcd_gotoxy(0,3);
            lcd_putsf("                    ");
            delay_ms(200);
            run_mode2();
         }
         if(mode_run==3)
         {
            lcd_gotoxy(0,0);
            lcd_putsf("  CHE DO : MODE 3   ");      
            put_time_info();
            lcd_putchar(' ');
            put_date_info();
            lcd_gotoxy(0,2);
            lcd_putsf("                    ");
            lcd_gotoxy(0,3);
            lcd_putsf("                    ");
         }
      }
      break;
      // chay chuong trinh setup time
      case 1:
      {
         set_time();
      }
      break;
      // chay chuong trinh setup date
      case 2:
      {
         set_date();
      }
      break;
      // chay chuong trinh setup time
      case 3:
      {
         set_mode();
      }
      break;
      // neu dang o mode 2 setup thoi gian on off
      case 4:
      {
         //
         if(mode_run==2)
            set_time_on_off();
         if(mode_run==1)
            menu_system=0;    
         if(mode_run==3)
            dk_bang_tay();    
      }
      break;
      // neu dang o mode 3 setup nhiet do on off
      default:
      break;
   }
}
